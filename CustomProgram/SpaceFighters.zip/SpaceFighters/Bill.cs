﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Bill
    {
        private Bitmap img;
        private Monster monster;
        private float x;
        private float y;
        public Bill(float pos_x,float pos_y)
        {
            x = pos_x;
            y = pos_y;
            img = SplashKit.LoadBitmap("Bill", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Bill.png");
        }
        public void Draw()
        {
            SplashKit.DrawBitmap(img, x, y);
            SplashKit.DrawText(monster.Description, Color.White, this.X, this.Y - 50);
        }
        public float X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }
        public float Y
        {
            get
            {
                return y;

            }
            set
            {
                y = value;
            }
        }
        public Monster Monster
        {
            get
            {
                return monster;
            }
            set
            {
                monster = value;
            }
        }
    }
}

