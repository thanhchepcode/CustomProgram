﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class BlackHoleBullet:Bullet
    {
        private float freeze_time;
        public BlackHoleBullet(float x, float y):base(1,0.5f,x,y)
        {
            freeze_time = 90;
            this.Image = SplashKit.LoadBitmap("Black Hole Image", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/black_hole_bullet.png");
        }
        public override void Draw()
        {
            DrawImage();
            SpecialEffect();

        }
        public void SpecialEffect()
        {
            // The special effect allows the bullet to stay at where it is after freeze_time
            freeze_time = freeze_time - 1;
            if(freeze_time <= 0)
            {
                this.Speed = 0;
            }
        }
        public override void ActivateDeadTime()
        {
            SpecialEffect();
        }
        public override void Chase(float speed)
        {
            // The reason why chase is overridden here is because I don't want the black hole bullet to chase the player when it is summoned by the galaxy like the star.
            freeze_time = freeze_time - 1;
            if (freeze_time <= 0)
            {
                this.Speed = 0;
            }
        }
    }
}

