﻿using System;
using SplashKitSDK;

namespace SpaceFighters
{
    public class Bullet:Item
    {
        private float _speed;
        private float _damage;
        private int dead_time;
        public Bullet(float dam,float speed,float pos_x, float pos_y) :base(pos_x,pos_y)
        {
            dead_time = 120;
            _damage = dam;
            _speed = speed;
        }
        public override void Effect(Entities s)
        {
            s.HP = s.HP - _damage;
        }
        public override void Draw()
        {
            
        }
        public Boolean BulletOutofScreen()
        {
            // If either one of x or y is larger or smaller than the 0 or the window length/width, the bullet dies.
            if (this.X <= 0 || this.X >= 800 || this.Y <= 0 || this.Y >= 600)
            {
                return true;
            }
            return false;
        }
        public void DrawImage()
        {
            // Draw the bullet if it is not dead.
            if (BulletOutofScreen())
            {
                this.Dead = true;
            }
            // Only draw the bullet if it is still alive.
            if (this.Dead == false)
            {
                SplashKit.DrawBitmap(this.Image, this.X, this.Y);
                this.Y = this.Y - this.Speed;
            }
        }

        public virtual void ActivateDeadTime()
        {
            // Some bullets will be killed after the dead_time goes below 0.
            dead_time = dead_time - 1;
            if(dead_time == 0)
            {
                this.Dead = true;
            }
        }
        public float Speed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }
        }
        public float Damage
        {
            get
            {
                return _damage;
            }
            set
            {
                _damage = value;
            }
        }
    }
}

