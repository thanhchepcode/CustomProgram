﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class SpaceshipBullet:Bullet
    {
        public SpaceshipBullet(float dam, float s, float pos_x,float pos_y):base(dam,s,pos_x,pos_y)
        {
            this.Image = SplashKit.LoadBitmap("Spaceship bullet", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Bullet-PNG-Pic.png");
        }
        public override void Draw()
        {
            DrawImage();
        }
    }
}

