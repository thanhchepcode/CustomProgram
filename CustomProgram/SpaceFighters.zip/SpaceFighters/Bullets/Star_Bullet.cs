﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Star_Bullet:Bullet
    {
        private float go_up_time;
        public Star_Bullet(float pos_x,float pos_y):base(1,4,pos_x,pos_y)
        {
            go_up_time = 90;
            this.Image = SplashKit.LoadBitmap("Star_bullet", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/star_bullet.png");
        }
        public override void Draw()
        {
            DrawImage();
            SpecialEffect();
        }
        public void SpecialEffect()
        {
            // The star bullet will only go up for 90/ fps seconds before going down. 
            go_up_time = go_up_time - 1;
            if(go_up_time <= 0)
            {
                this.Speed = -1;
            }
        }
        
        
    }
    
}

