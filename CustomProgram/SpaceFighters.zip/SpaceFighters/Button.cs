﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Button
    {
        private Bitmap img;
        private float x;
        private float y;
        private Rectangle rect;
        public Button(Bitmap image, float pos_x, float pos_y)
        {
            img = image;
            x = pos_x;
            y = pos_y;
            rect = SplashKit.RectangleFrom(x, y, img.Width, img.Height);
        }
        public void Draw()
        {
            SplashKit.DrawBitmap(img, x, y);
        }
        public bool IsClicked(Point2D point)
        {
            
            // A rectangle is created exactly the size of the button. If the rectangle is clicked, the button is also clicked.
            if (SplashKit.MouseClicked(MouseButton.LeftButton))
            {
                if (SplashKit.PointInRectangle(point, rect))
                {
                    return true;
                }
            }
                    
            
            return false;
        }

    }
}

