﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class CollisionHandler
    {
        private Monster m;
        private Spaceship s;
        private List<Item> items;
        private List<Chicken> chickens;
        public CollisionHandler(Spaceship spaceship, List<Item> list_item, List<Chicken> list_chicken)
        {
            chickens = list_chicken;
            s = spaceship;
            items = list_item;
        }
        public Boolean CheckCollide(GameObject g1, GameObject g2)
        {
            // This is when abstraction really comes into play. Regardless of the type of GameObject, they all has images.
            if (SplashKit.BitmapCollision(g1.Image, g1.X, g1.Y, g2.Image, g2.X, g2.Y))
            {
                return true;
            }
            return false;
        }

        public void Check()
        {
            foreach (Chicken chicken in chickens)
            {
                if (chicken.HP <= 0)
                {
                    chicken.Dead = true;
                }
                
                foreach (Bullet b in s.Bullets)
                {
                    if (CheckCollide(b, chicken) && b.Dead == false && chicken.Dead == false)
                    {
                        chicken.HP = chicken.HP - 1;
                        b.Dead = true;
                    }
                }
            }


            // Check if the player can take items
            if (items != null)
            {
                foreach (Item i in items)
                {
                    if (i.Dead == false)
                    {
                        if (CheckCollide(s, i))
                        {
                            i.Effect(s);
                            i.Dead = true;
                        }
                    }
                }
            }
        }
        public void CheckMonsterState(Monster m)
        {
            if (m.Dead == false && s.Dead == false)
            {
                if (CheckCollide(s, m))
                {
                    s.Dead = true;
                }
            }


            // If the bullet hits the monster, HP of the monster decreases by 1.
            foreach (Bullet b in s.Bullets)
            {
                if (b.Dead == false && m.Dead == false)
                {
                    if (CheckCollide(b, m))
                    {
                        b.Dead = true;
                        m.HP = m.HP - b.Damage;
                    }
                }
            }

            if (m.Dead == false)
            {
                foreach (GameObject gameObject in m.Inventory.List)
                {
                    if (gameObject is Bullet)
                    {
                        if (CheckCollide(gameObject, s) && gameObject.Dead == false)
                        {
                            s.HP = s.HP - 1;
                            gameObject.Dead = true;
                        }

                    }
                    else if (gameObject is Monster)
                    {
                        if (((Monster)gameObject).HP <= 0)
                        {


                            ((Monster)gameObject).Dead = true;
                        }
                        if (CheckCollide(gameObject, s) && gameObject.Dead == false)
                        {
                            s.Dead = true;
                        }
                        foreach (Bullet b in s.Bullets)
                        {
                            if (CheckCollide(gameObject, b) && ((Monster)gameObject).Dead == false && b.Dead == false)
                            {
                                ((Monster)gameObject).HP = ((Monster)gameObject).HP - 1;
                                b.Dead = true;
                            }
                        }
                    }

                }


            }

            if (m.HP <= 0)
            {
                m.Dead = true;
            }


            if (m.Dead == true || m.HP <= 0)
            {
                m.Dead = true;
                foreach (GameObject b in m.Inventory.List)
                {
                    b.Dead = true;
                }
            }
        }

    }
}

