﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public abstract class Entities:GameObject
    {
        private float hp;
        private Boolean dead;
        private float vel_x;
        private float vel_y;
        private string des;
        private List<Bullet> bullets;
        public Entities(float x, float y, string description):base()
        {
            // Entities include monsters and players.
            bullets = new List<Bullet> { };
            this.X = x;
            this.Y = y;
            des = description;
        }
        public float HP
        {
            get
            {
                return hp;
            }
            set
            {
                hp = value;
            }
        }
        public float Vel_x
        {
            get
            {
                return vel_x;
            }
            set
            {
                vel_x = value;
            }
        }
        public float Vel_y
        {
            get
            {
                return vel_y;
            }
            set
            {
                vel_y = value;
            }
        }
        public string Description
        {
            get
            {
                return des;
            }
            set
            {
                des = value;
            }
        }

        public List<Bullet> Bullets
        {
            get
            {
                return bullets;
            }
            set
            {
                bullets = value;
            }
        }
        public abstract void DrawHP();
    }
}

