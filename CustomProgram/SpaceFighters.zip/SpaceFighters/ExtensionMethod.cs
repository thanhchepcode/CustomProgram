﻿using System;
using System.IO;
using SplashKitSDK;
namespace SpaceFighters
{
    public static class ExtensionMethods
    {
        public static int ReadInteger(this StreamReader reader)
        {
            // Read the line and convert it to integer type.
            return Convert.ToInt32(reader.ReadLine());
        }
        public static float ReadSingle(this StreamReader reader)
        {
            // Read the line and convert it to float type.
            return Convert.ToSingle(reader.ReadLine());
        }

    }
}

