﻿using System;
namespace SpaceFighters
{
    public class BlackHoleFactory:MonsterFactory
    {
        public Monster GetMonster()
        {
            Monster blackhole = new BlackHole(400, 200, "THe black hole. Be careful because it can teleport.");
            return blackhole;
        }
    }
}

