﻿using System;
namespace SpaceFighters
{
    public class BombFactory:ItemFactory
    {
        public Item GetItem()
        {
            Random random = new Random();
            Item bomb = new Bomb(random.Next(50), random.Next(600));
            return bomb;
        }
    }
}

