﻿using System;
namespace SpaceFighters
{
    public class GalaxyFactory:MonsterFactory
    {
        public Monster GetMonster()
        {
            Monster galaxy = new Galaxy(400, 50, "The galaxy. The one that can create other planets");
            return galaxy;
        }
    }
}

