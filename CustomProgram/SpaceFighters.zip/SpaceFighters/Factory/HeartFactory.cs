﻿using System;
namespace SpaceFighters
{
    public class HeartFactory:ItemFactory
    {
        public Item GetItem()
        {
            Random random = new Random();
            Item heart = new Heart(random.Next(50), random.Next(600));
            return heart;
        }
    }
}

