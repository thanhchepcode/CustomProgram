﻿using System;
namespace SpaceFighters
{
    interface ItemFactory
    {
        Item GetItem();
    }
}

