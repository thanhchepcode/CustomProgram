﻿using System;
namespace SpaceFighters
{
    public class ItemFactoryCreator
    {
        private ItemFactory factory;
        public ItemFactoryCreator()
        {
        }
        public Item CreateItem()
        {
            Random random = new Random();
            int choice = random.Next(10);
            // Random the item created.
            if(choice == 1)
            {
                factory = new BombFactory();
                return factory.GetItem();
            }
            else if(choice == 2)
            {
                factory = new HeartFactory();
                return factory.GetItem();
            }
            else
            {
                factory = new RockFactory();
                return factory.GetItem();
            }
            // Based on this function, rock is 8 times more likely to be created than heart and bomb.
            
        }
    }

}

