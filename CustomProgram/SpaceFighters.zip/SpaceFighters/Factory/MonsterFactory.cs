﻿using System;
namespace SpaceFighters
{
    interface MonsterFactory
    {
        Monster GetMonster();
    }
}

