﻿using System;
namespace SpaceFighters
{
    public class MonsterFactoryCreator
    {
        private MonsterFactory monsterFactory;
        private Monster monster;
        public MonsterFactoryCreator()
        {
        }
        public Monster CreateMonster(int choice)
        {
            // Create monster based on choice in the main program.
            switch (choice)
            {
                case 1:
                    monsterFactory = new PlanetFactory();
                    monster = monsterFactory.GetMonster();
                    return monster;
                case 2:
                    monsterFactory = new StarFactory();
                    monster = monsterFactory.GetMonster();
                    return monster;
                case 3:
                    monsterFactory = new BlackHoleFactory();
                    monster = monsterFactory.GetMonster();
                    return monster;
                case 4:
                    monsterFactory = new GalaxyFactory();
                    monster = monsterFactory.GetMonster();
                    return monster;
            }
            return null;
        }
    }
}

