﻿using System;
namespace SpaceFighters
{
    public class PlanetFactory : MonsterFactory
    {
        public Monster GetMonster()
        {
            Monster monster = new Planet(400, 100, "Planet. The weakest monster of the game");
            return monster;
        }
    }
}

