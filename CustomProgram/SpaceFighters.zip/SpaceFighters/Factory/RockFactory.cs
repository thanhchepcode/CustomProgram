﻿using System;
namespace SpaceFighters
{
    public class RockFactory:ItemFactory
    {
        private Item rock;
        public Item GetItem()
        {
            Random random = new Random();
            rock = new Rock(random.Next(800), 0);
            return rock;
        }
    }
}

