﻿using System;
namespace SpaceFighters
{
    public class StarFactory : MonsterFactory
    {
        public Monster GetMonster()
        {
            Monster star = new Star(400, 50, "The star. Stronger than the planet, can shoot bullets");
            return star;
        }
    }
}

