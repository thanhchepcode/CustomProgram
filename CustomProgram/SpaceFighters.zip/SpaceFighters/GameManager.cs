﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class GameManager
    {
        private GamePage page;
        private static GameManager manager; //singleton pattern
        public GameManager(Window window)
        {
            // Game manager allows only one page to appear at a time.
            page = new MainMenu(window);
        }
        public GamePage CurrentPage
        {
            get
            {
                return page;
            }
            set
            {
                page = value;
            }
        }
        public void Update()
        {
            page.Update();
        }
        public static GameManager GetGameManager(Window window)
        {
            if(manager == null)
            {
                manager = new GameManager(window);
            }
            return manager;
        }
    }
}

