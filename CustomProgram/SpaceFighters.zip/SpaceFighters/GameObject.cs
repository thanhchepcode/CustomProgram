﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public abstract class GameObject
    {
        private Bitmap img;
        private Boolean dead;
        private float pos_x;
        private float pos_y;
        private Entities enemy;
        public GameObject()
        {
            // The highest abstraction of all the objects in the games. It has images, position x and y. Some can chase the enemy (bullets and mosnter)
            dead = false;
        }
        public Entities Enemy
        {
            get
            {
                return enemy;
            }
            set
            {
                enemy = value;
            }
        }
        public Boolean Dead
        {
            get
            {
                return dead;
            }
            set
            {
                dead = value;
            }
        }
        public float X
        {
            get
            {
                return pos_x;
            }
            set
            {
                pos_x = value;
            }
        }
        public float Y
        {
            get
            {
                return pos_y;
            }
            set
            {
                pos_y = value;
            }
        }
        public virtual void Chase(float speed)
        {
            // Chase the enemy given its position.
            if (enemy.X > this.X)
            {
                this.X = this.X + speed;
            }
            else
            {
                this.X = this.X - speed;
            }
            if (enemy.Y > this.Y)
            {
                this.Y = this.Y + speed;
            }
            else
            {
                this.Y = this.Y - speed;
            }
        }
        public Bitmap Image
        {
            get
            {
                return img;
            }
            set
            {
                img = value;
            }
        }
        public abstract void Draw();
    }
}

