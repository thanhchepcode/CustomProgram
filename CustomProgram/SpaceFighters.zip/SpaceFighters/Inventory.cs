﻿using System;
namespace SpaceFighters
{
    public class Inventory
    {
        private List<GameObject> _inventory;
        public Inventory()
        {
            // Only monsters have the inventory to store its items whether that's bullets or monsters.
            _inventory = new List<GameObject> { };
        }
        public void AddMonster(Monster m)
        {
            _inventory.Add(m);
        }
        public void AddBullet(Bullet b)
        {
            _inventory.Add(b);
        }
        public void Update()
        {
            // Draw the game object in the inventory
            foreach(GameObject inInventory in _inventory)
            {
                if (inInventory.Dead == false)
                {
                    inInventory.Draw();
                }
            }
        }
        public int Count
        {
            get
            {
                return _inventory.Count();
            }
        }
        public List<GameObject> List
        {
            get
            {
                return _inventory;
            }
            set
            {
                _inventory = value;
            }
        }
    }
}

