﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Bomb:Item
    {
        private Bitmap explo_img;
        private SoundEffect explosionSound;
        private int explo_time;
        public Bomb(float x, float y):base(x,y)
        {
            explosionSound = new SoundEffect("Explosion", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/explosion_sound.wav");
            explo_img = SplashKit.LoadBitmap("Explosion", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/explosion.jpeg");
            explo_time = 30;
            this.Image = SplashKit.LoadBitmap("Bomb", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Bomb.png");
        }
        public override void Draw()
        {
            // Draw the bomb moving.
            if(this.Dead == false)
            {
                SplashKit.DrawBitmap(this.Image, this.X, this.Y);
                this.X = this.X + 1;
                this.Y = this.Y + 1;
            }
            // Draw the explosion part for half a second.
            if(this.Dead == true && explo_time > 0)
            {
                SplashKit.DrawBitmap(explo_img, this.X, this.Y);
                explo_time = explo_time - 1;
                explosionSound.Play();
            }
        }
        public override void Effect(Entities s)
        {
            //The effect of the bomb to the player
            s.HP = s.HP - 1;

        }
    }
}

