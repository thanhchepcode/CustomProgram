﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Heart:Item
    {
        public Heart(float x, float y): base(x,y)
        {
            this.Image = SplashKit.LoadBitmap("Heart", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Heart.png");
        }
        public override void Effect(Entities s)
        {
            s.HP = s.HP + 1;
        }
        public override void Draw()
        {
            if(this.Dead == false)
            {
                SplashKit.DrawBitmap(this.Image, this.X, this.Y);
                this.X = this.X + 1;
                this.Y = this.Y + 1;
            }
            

        }
        public void CheckDead()
        {
            if(this.X >=800 || this.Y >= 600)
            {
                this.Dead = true;
            }
        }

    }
}

