﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public abstract class Item:GameObject
    {
        public Item(float Pos_x, float Pos_y):base()
        {
            this.X = Pos_x;
            this.Y = Pos_y;
        }
        public abstract void Effect(Entities s);
        // Each item will have its own effect on the entities.
    }
}

