﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Rock: Item
    {
        public Rock(float x, float y):base(x,y)
        {
            this.Image = SplashKit.LoadBitmap("rock", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/rock.png");
        }
        public override void Draw()
        {
            if(this.Dead == false)
            {
                SplashKit.DrawBitmap(this.Image, this.X, this.Y);
                this.Y = this.Y + 5;
            }
        }
        public override void Effect(Entities s)
        {
            s.HP = s.HP - 1;
        }
    }
}

