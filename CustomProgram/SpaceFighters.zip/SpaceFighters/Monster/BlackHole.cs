﻿using System;
using SplashKitSDK;
using System.Diagnostics;
using System.Threading;
using System.Timers;
namespace SpaceFighters
{
    public class BlackHole:Monster
    {
        private Random rnd;
        private int new_bullet_time;
        private Bullet b;
        public BlackHole(float x, float y, string desc):base(x,y,desc)
        {
            this.ID = 4;
            new_bullet_time = 180; 
            this.Speed = 0.5f;
            this.HP = 50;

            b = new BlackHoleBullet(this.X, this.Y);
            this.Inventory.AddBullet(b);
            rnd = new Random();
            this.Image = SplashKit.LoadBitmap("Black Hole", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/black-hole.jpeg");

        }
        public void Teleport()
        {
            // Teleport the black hole into a random position not too close to the spaceship.
            this.X = rnd.Next(1, 800);
            this.Y = rnd.Next(1, 600);
            while (Math.Abs(this.X - Enemy.X) <= 50)
            {
                this.X = rnd.Next(1, 800);
            }
            
        }

        public override void Draw()
        {
            DrawImage();
            // Teleport the spaceship after a random time.
            int call = rnd.Next(3600);
            if (call <= 1)
            {
                Teleport();
            }
            Chase(this.Speed);
            // Create the new bullet after it gets out of the screen or if 3 seconds have passed.
            if (new_bullet_time <= 0)
            {
                b = new BlackHoleBullet(this.X, this.Y);
                this.Inventory.AddBullet(b);
                new_bullet_time = 180;
            }

            this.Inventory.Update();
            // Decrease the time to generate new bullet by 1 after every time it is looped through.
            new_bullet_time = new_bullet_time - 1;


        }

    }
}

