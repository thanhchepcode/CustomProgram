﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Chicken:Monster
    {
        public Chicken(float x, float y, string desc):base(x,y,desc)
        {
            this.HP = 1;
            this.Image = SplashKit.LoadBitmap("Chicken", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Chicken.png");
        }
        public override void Draw()
        {
            DrawImage();
            Chase(0.5f);

        }
        public void CheckDead()
        {

        }
        public override void Chase(float speed)
        {
            // This allows the chickens to go down 
            this.Y = this.Y + speed;

            // If the chicken goes below the screen, the player dies.
            if(this.Y >= 600 && this.Dead == false)
            {
                this.Enemy.Dead = true;
            }
        }
    }
}

