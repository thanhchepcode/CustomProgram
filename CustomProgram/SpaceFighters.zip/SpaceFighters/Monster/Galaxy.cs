﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Galaxy:Monster
    {
        private Monster monster;
        private int new_monster_time;
        private Random random;
        private List<Monster> monsters; // composite design pattern
        public Galaxy(float x, float y, string desc): base(x,y,desc)
        {
            this.ID = 5;
            random = new Random();
            this.Speed = 0.5f;
            new_monster_time = 300;
            monsters = new List<Monster> { };
            this.Image = SplashKit.LoadBitmap("Galaxy", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Galaxy.png");
            this.HP = 80;

        }
        public override void Draw()
        {
            DrawImage();
            // Create new planet monster every 5 seconds. 
            this.Inventory.Update();
            

        }

        public override void SpecialEffect()
        {
            // The special effect of this monster is to create new other monsters
            monster = new Planet(this.X + 50, this.Y + 50, "Son of the galaxy.");
            monster.Enemy = this.Enemy;
            monster.HP = 14;
            if (new_monster_time == 0)
            {
                this.Inventory.AddMonster(monster);
                new_monster_time = 300;
            }

            new_monster_time = new_monster_time - 1;
        }

        public override void UltimateEffect()
        {
            // Unlike the special effect, the ultiamte effect allows the galaxy to create the stars and the black hole as well.
            if(new_monster_time == 0)
            {
                int choose = random.Next(4);
                switch (choose)
                {
                    case 2:
                        Monster new_star = new Star(this.X, this.Y, "Son of the galaxy");
                        new_star.Enemy = this.Enemy;
                        new_star.HP = 14;
                        this.Inventory.AddMonster(new_star);
                        break;
                    case 3:

                        Monster new_black_hole = new BlackHole(this.X, this.Y, "Son of the galaxy");
                        new_black_hole.Enemy = this.Enemy;
                        new_black_hole.HP = 14;
                        this.Inventory.AddMonster(new_black_hole);
                        break;
                }
                new_monster_time = 300;
            }

            // Create new monsters after every 300/fps seconds.
            new_monster_time = new_monster_time - 1;
            
        }
        public List<Monster> Monsters
        {
            get
            {
                return monsters;
            }
        }
         
    }
}

