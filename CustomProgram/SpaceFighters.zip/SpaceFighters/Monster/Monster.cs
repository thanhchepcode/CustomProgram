﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public abstract class Monster:Entities
    {
        private float speed;
        private Inventory inventory;
        private int monsterID;
        public Monster(float x, float y, string desc) : base(x, y, desc) 
        {
            inventory = new Inventory();
            this.HP = 3;
        }

        
        public float Speed
        {
            get
            {
                return speed;
            }
            set
            {
                speed = value;
            }
        }
        
        public void DrawImage()
        {
            // if the monster is dead, the draw function is not executed.
            SplashKit.DrawBitmap(this.Image, this.X, this.Y);
        }
        public override void DrawHP()
        {
            // Draw the HP of the monster at the top left of the screen.
            for (int i = 0; i < this.HP; i++)
            {
                SplashKit.FillRectangle(Color.Orange, 50 + i * 20, 50, 20, 20);
            }
        }

        public virtual void SpecialEffect()
        {
        }

        public virtual void UltimateEffect()
        {

        }


        public Inventory Inventory
        {
            get
            {
                return inventory;
            }
            set
            {
                inventory = value;
            }
        }
        
        public int ID
        {
            get
            {
                return monsterID;
            }
            set
            {
                monsterID = value;
            }
        }

    }
}

