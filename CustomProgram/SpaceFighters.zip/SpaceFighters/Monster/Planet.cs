﻿using System;
using SplashKitSDK;

namespace SpaceFighters
{
    public class Planet:Monster
    {
        public Planet(float x, float y, string desc): base(x,y,desc)
        {
            this.ID = 2;
            this.Speed = 1.5f;
            this.Image = SplashKit.LoadBitmap("planet", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/planet.png");
            this.HP = 10;
        }
        public override void Draw()
        {
            // The planet can chase the players.
            DrawImage();
            Chase(this.Speed);
        }
    }
}

