﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Star:Monster
    {
        private Bullet b;
        public Star(float x, float y, string desc):base(x,y,desc)
        {
            this.ID = 3;
            this.Speed = 1f;
            this.HP = 40;
            b = new Star_Bullet(this.X, this.Y);
            this.Inventory.AddBullet(b);
            this.Image = SplashKit.LoadBitmap("Star", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/star.jpeg");
        }
        public override void Draw()
        {
            DrawImage();
            // Whenver the buller goes out of screen or dies(collides with the player), make the new bullet
            if (b.BulletOutofScreen() || b.Dead == true)
            {
                b = new Star_Bullet(this.X, this.Y);
                this.Inventory.AddBullet(b);
            }
            Chase(this.Speed);
            this.Inventory.Update();
        }
    }
}

