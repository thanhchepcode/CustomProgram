﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class EasyGame:GamePage
    {
        private Window window;
        private Initialize_Page initialize;
        private Spaceship spaceship;
        private Monster monster;
        private List<Chicken> chickens;
        private List<Item> items;
        private Boolean create_monster;
        private int choice;
        private Bitmap background;
        private Boolean endgame;
        private CollisionHandler handler;
        private Boolean playMusic;
        private Music backgroundmusic;
        private SavingManager savingManager;
        private Button instruction;
        private Boolean have_chicken;

        public EasyGame(Window game_window)
        {
            have_chicken = true;
            savingManager = new SavingManager(game_window);
            playMusic = true;
            endgame = false;
            choice = 1;
            window = game_window;
            initialize = new Initialize_Page();
            background = initialize.Background;

            spaceship = initialize.CreateSpaceship();

            chickens = initialize.CreateChicken(4,2,spaceship);
            items = new List<Item> { };

            handler = new CollisionHandler(spaceship, items, chickens);
            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 500);
        }

        public EasyGame(Window game_window,Spaceship s, Monster m, List<Item> lst_item)
        {
            // This constructor is used to load game after the instruction button is clicked. This stage is when monster has been created.
            have_chicken = false;
            initialize = new Initialize_Page();

            window = game_window;
            spaceship = s;
            monster = m;
            items = lst_item;

            chickens = initialize.CreateChicken(4, 2, spaceship);
            initialize.KillChicken(chickens);

            choice = monster.ID;
            savingManager = new SavingManager(window);
            playMusic = true;
            endgame = false;
            background = initialize.Background;

            handler = new CollisionHandler(spaceship, items, chickens);
            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 500);
        }

        public EasyGame(Window game_window, Spaceship s, List<Chicken> chickenss, List<Item> lst_item)
        {
            // This constructor is used to load game after the instruction button is clicked. This stage is chickens are still on the screen.
            have_chicken = true;
            initialize = new Initialize_Page();

            window = game_window;
            spaceship = s;
            items = lst_item;

            chickens = chickenss;

            choice = 1;
            savingManager = new SavingManager(window);
            playMusic = true;
            endgame = false;
            background = initialize.Background;

            handler = new CollisionHandler(spaceship, items, chickens);
            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 0);

        }

        public void Update()
        {
            // Play the music background.
            if (playMusic)
            {
                backgroundmusic.Play(100);
            }


            do
            {
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();
                SplashKit.DrawBitmap(background, 0, 0);
                instruction.Draw();

                // If the instruction button is clicked to view the instrction, save the game data.
                if (instruction.IsClicked(SplashKit.MousePosition()))
                {
                    if (monster != null)
                    {
                        savingManager.Save_with_monster(spaceship, monster, items, "/Users/khanhvu/Desktop/Spacefighters.txt", true);
                        endgame = true;
                        InstructionPage(have_chicken);
                    }
                    else
                    {
                        savingManager.Save_with_Chicken(spaceship, chickens, items, "/Users/khanhvu/Desktop/Spacefighters.txt", true);
                        endgame = true;
                        InstructionPage(have_chicken);
                    }
                }
                
                

                // When escape key is pressed, back to main menu.
                if (SplashKit.KeyTyped(KeyCode.EscapeKey))
                {
                    endgame = true;
                    PreviousPage();
                }

                // create_monster is true when all the chickens have been killed.
                if (create_monster)
                {
                    have_chicken = false;
                    if(monster == null)
                    {
                        monster = initialize.CreateMonsters(monster,spaceship,choice);

                        choice = choice + 1;
                    }
                    else
                    // If the previous monster has died, create a new one.
                    {
                        if(monster.Dead == true)
                        {
                            monster = initialize.CreateMonsters(monster, spaceship, choice);

                            choice = choice + 1;
                        }
                    }
                }

                items = initialize.CreateItems(items);

                handler.Check();
                
                if(monster!= null)
                {
                    handler.CheckMonsterState(monster);
                }

                create_monster = true;

                // If the spaceship is dead, back to the main menu.
                if (spaceship.Dead == false)
                {
                    spaceship.Draw();
                }
                else
                {
                    endgame = true;
                    PreviousPage();
                }

                // Draw the monster and its HP. The reason why drawHP is not included in the draw function is because when the mosnter is created by the galaxy, we will not draw its HP.
                if (monster != null)
                {
                    monster.Draw();
                    monster.DrawHP();
                    monster.SpecialEffect();
                }

                foreach (Item item in items)
                {
                    item.Draw();
                }

                // Draw the chicken, and if the chickens are still alive, monsters are not created.
                foreach (Chicken chicken in chickens)
                {
                    if (chicken.Dead == false)
                    {
                        chicken.Draw();
                        create_monster = false;
                    }

                }

                SplashKit.RefreshScreen();
                window.Refresh(60);

                if (window.CloseRequested)
                {
                    endgame = true;
                }

                // When galaxy is dead, the game is won.

                if(choice == 5 && monster.Dead == true)
                {
                    endgame = true;
                    NextPage();
                }
            }
            while (endgame == false);

            playMusic = false;
            
        }
        public void PreviousPage()
        {
            // Stop the music.
            backgroundmusic.DoFree();

            GameManager.GetGameManager(window).CurrentPage = new MainMenu(window);
        }
        public void NextPage()
        {
            backgroundmusic.DoFree();
            GameManager.GetGameManager(window).CurrentPage = new Victory(window);
        }
        public void InstructionPage(Boolean have_chicken)
        {
            backgroundmusic.DoFree();
            GameManager.GetGameManager(window).CurrentPage = new InstructionPage(window, true,true,have_chicken);
        }
    }
}

