﻿using System;
namespace SpaceFighters
{
    public interface GamePage // state pattern
    {
        void NextPage();
        void PreviousPage();
        void Update();
        
    }
}

