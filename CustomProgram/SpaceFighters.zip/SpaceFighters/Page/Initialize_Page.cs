﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Initialize_Page
    {
        private Random random;
        private Bitmap background_img;
        private ItemFactoryCreator itemFactory;
        private MonsterFactoryCreator monsterCreator;
        public Initialize_Page()
        {
            monsterCreator = new MonsterFactoryCreator();
            background_img = SplashKit.LoadBitmap("background", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/bg.jpeg");
            random = new Random();
            itemFactory = new ItemFactoryCreator();
            
        }

        public List<Item> CreateItems(List<Item> items)
        {
            // Crreate new items randomly.
            int generate = random.Next(10000);
            if (generate <= 100)
            {
                Item item = itemFactory.CreateItem();
                items.Add(item);
            }
            return items;

        }


        public Spaceship CreateSpaceship()
        {
            Spaceship spaceship = new Spaceship(400, 500, "no desc yet.");
            return spaceship;
        }

        public List<Chicken> CreateChicken(int column, int row, Spaceship spaceship)
        {
            // Create new army of chickens based on the column and row inputed.

            List<Chicken> chickens = new List<Chicken> { };
            for (int j = 0; j <= 100*row; j = j + 100)
            {
                for (int i = 100; i <= 100*column+100; i = i + 100)
                {
                    Chicken chicken = new Chicken(i, j, "Chicken");
                    chicken.Enemy = spaceship;
                    chickens.Add(chicken);
                }
            }
            return chickens;
        }

        public void KillChicken(List<Chicken> chickens)
        {
            // Kill the chickens when necessary.
            foreach(Chicken chicken in chickens)
            {
                chicken.Dead = true;
            }
        }

       
        public Monster CreateMonsters(Monster monster, Spaceship spaceship, int choice)
        {
            // Create new monster.
            if (choice <= 4)
            {
                
                monster = monsterCreator.CreateMonster(choice);
                monster.Enemy = spaceship;
            }

            return monster;
        }


        
        

        public Bitmap Background
        {
            get
            {
                return background_img;
            }
            
        }
    }
}

