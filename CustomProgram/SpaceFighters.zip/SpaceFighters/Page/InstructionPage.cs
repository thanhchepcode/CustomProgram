﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class InstructionPage:GamePage
    {
        private Button main_menu;
        private Window window;
        private Bitmap bg_img;
        private Button button;
        private Bitmap play_img;
        private Boolean in_game;
        private SavingManager savingManager;
        private Boolean have_chicken;
        private Boolean easy;
        
        public InstructionPage(Window game_window, Boolean playing, Boolean easy_game, Boolean have_chickens)
        {
            window = game_window;
            easy = easy_game;
            have_chicken = have_chickens;
            savingManager = new SavingManager(window);
            in_game = playing;
            play_img = SplashKit.LoadBitmap("Play", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/play_button.png");
            button = new Button(play_img, 600, 0);

            
            main_menu = new Button(SplashKit.LoadBitmap("main_menu", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Main_menu.png"),0,0);
            bg_img = SplashKit.LoadBitmap("background", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/bg.jpeg");


        }
        public void PreviousPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new MainMenu(window);
        }
        
        public void Update()
        {
            // The below chunk of code draws the text out in the instruction page.

            SplashKit.ProcessEvents();
            window.Clear(Color.White);
            SplashKit.DrawBitmap(bg_img, 0, 0);
            SplashKit.DrawBitmap(SplashKit.LoadBitmap("chicken", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Chicken.png"), 0, 150);

            SplashKit.DrawText("This is the chicken. There will be lots of them. Each can be killed by one bullet", Color.Gray, 0, 100);
            SplashKit.DrawBitmap(SplashKit.LoadBitmap("planet", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/planet.png"), 0, 200);
            SplashKit.DrawBitmap(SplashKit.LoadBitmap("star", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/star.jpeg"), 150, 200);
            SplashKit.DrawBitmap(SplashKit.LoadBitmap("black_hole", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/black-hole.jpeg"), 300, 200);
            SplashKit.DrawBitmap(SplashKit.LoadBitmap("galaxy", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/galaxy.png"), 450, 200);

            
            SplashKit.DrawText("Those are the monsters that you have to face. Leftmost is the planet. It can chase you very fast! ", Color.Brown, 0, 300);
            SplashKit.DrawText("Next is the star. It can also chase you but also can shoot bullet", Color.Red, 0, 350);
            SplashKit.DrawText("Next is the black hole. It can chase you, teleport and put mine", Color.Blue, 0, 400);
            SplashKit.DrawText("You get the galaxy at the end, it can create other monsters", Color.Yellow, 0, 450);

            SplashKit.DrawBitmap(SplashKit.LoadBitmap("spaceship", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/spaceship.1.png"), 450, 500);
            SplashKit.DrawText("This is you. Use the space to shoot bullet and left and button to move left, etc.",Color.AliceBlue, 0, 550);
            // This function has the same logic in the game page. 
            if (in_game)
            {
                // If the game is currently being played, draw the button.

                button.Draw();
                if (button.IsClicked(SplashKit.MousePosition()))
                {

                    if (easy)
                    {
                        // If the game is in the easy mode, load the easy page.
                        if (have_chicken)
                        {
                            GamePage page = savingManager.Load_With_Chicken("/Users/khanhvu/Desktop/Spacefighters.txt", true);
                            NextPage(page);
                        }
                        else
                        {
                            GamePage page = savingManager.Load("/Users/khanhvu/Desktop/Spacefighters.txt", true);
                            NextPage(page);
                        }
                        
                    }
                    else
                    {
                        if (have_chicken)
                        {
                            GamePage page = savingManager.Load_With_Chicken("/Users/khanhvu/Desktop/Spacefighters.txt", true);
                            NextPage(page);
                        }
                        else
                        {
                            GamePage page = savingManager.Load("/Users/khanhvu/Desktop/Spacefighters.txt", false);
                            NextPage(page);
                        }
                        
                    }
                }
            }
            main_menu.Draw();
            if (main_menu.IsClicked(SplashKit.MousePosition()))
            {
                PreviousPage();
            }

            window.Refresh(60);


        }

        public void NextPage()
        {

        }

        public void NextPage(GamePage page)
        {
            GameManager.GetGameManager(window).CurrentPage = page;
        }
        public void LoadMediumPage()
        {

        }  
    }
}

