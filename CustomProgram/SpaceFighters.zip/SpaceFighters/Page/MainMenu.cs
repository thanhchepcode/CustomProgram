﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class MainMenu:GamePage
    {
        private Window window;
        private Bitmap bg_img;
        private Button easy;
        private Bitmap easy_img;
        private Button medium;
        private Bitmap medium_img;
        private Button instruction;
        private Bitmap instruction_img;
        public MainMenu(Window game_window)
        {
            bg_img = SplashKit.LoadBitmap("bg", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Solar_system.png");
            window = game_window;
            easy_img = SplashKit.LoadBitmap("easy", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/easy.png");
            medium_img = SplashKit.LoadBitmap("medium", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/medium.png");
            instruction_img = SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png");
            easy = new Button(easy_img, 250, 300);
            medium = new Button(medium_img, 250, 400);
            instruction = new Button(instruction_img, 250, 500);


        }
        public void Update()
        {
            // The main menu has 3 main buttons: easy, medium and instruction buttons.

            SplashKit.ProcessEvents();
            window.Clear(Color.White);

            SplashKit.DrawBitmap(bg_img, 0, 0);
            easy.Draw();
            medium.Draw();
            instruction.Draw();
            
            if (easy.IsClicked(SplashKit.MousePosition()))
            {
                NextPage();
            }

            if (medium.IsClicked(SplashKit.MousePosition()))
            {
                MediumPage();
            }
            if (instruction.IsClicked(SplashKit.MousePosition()))
            {
                PreviousPage();
            }
            window.Refresh(60);
                
        }
        public void NextPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new EasyGame(window);

        }

        public void MediumPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new MediumGame(window);
        }
        public void PreviousPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new InstructionPage(window,false,false,false);
        }
    
    }
}

