﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class MediumGame : GamePage
    {
        private Window window;
        private Initialize_Page initialize;
        private Spaceship spaceship;
        private Monster monster;
        private List<Chicken> chickens;
        private List<Item> items;
        private Boolean create_monster;
        private int choice;
        private Bitmap background;
        private Boolean endgame;
        private CollisionHandler handler;
        private Random random;
        private Music backgroundmusic;
        private Boolean playMusic;
        private Button instruction;
        private SavingManager savingManager;
        private Boolean have_chicken;
        public MediumGame(Window game_window)
        {
            // Almost like the easy page, the differences are in the functions of the monsters and how many chickens are created.
            playMusic = true;

            have_chicken = true;
            random = new Random();
            endgame = false;
            choice = 1;
            window = game_window;
            initialize = new Initialize_Page();
            background = initialize.Background;

            spaceship = initialize.CreateSpaceship();
            spaceship.HP = 25;
            chickens = initialize.CreateChicken(4, 3, spaceship);
            items = new List<Item> { };
            savingManager = new SavingManager(game_window);

            handler = new CollisionHandler(spaceship, items, chickens);

            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 0);

        }

        public MediumGame(Window game_window, Spaceship s, Monster m, List<Item> lst_item)
        {
            have_chicken = false;
            random = new Random();
            initialize = new Initialize_Page();

            window = game_window;
            spaceship = s;
            monster = m;
            items = lst_item;

            chickens = initialize.CreateChicken(4, 2, spaceship);
            initialize.KillChicken(chickens);

            choice = monster.ID;
            savingManager = new SavingManager(window);
            playMusic = true;
            endgame = false;
            background = initialize.Background;

            handler = new CollisionHandler(spaceship, items, chickens);
            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 500);
        }


        public MediumGame(Window game_window, Spaceship s, List<Chicken> chickenss, List<Item> lst_item)
        {

            have_chicken = true;
            initialize = new Initialize_Page();

            window = game_window;
            spaceship = s;
            items = lst_item;

            chickens = chickenss;

            choice = 1;
            savingManager = new SavingManager(window);
            playMusic = true;
            endgame = false;
            background = initialize.Background;

            handler = new CollisionHandler(spaceship, items, chickens);
            backgroundmusic = new Music("background_music", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Music.mp3");
            instruction = new Button(SplashKit.LoadBitmap("instruction", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/instruction.png"), 600, 500);

        }

        public void Update()
        {

            if (playMusic)
            {
                backgroundmusic.Play(100);
            }

            do
            {

                
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();
                SplashKit.DrawBitmap(background, 0, 0);

                instruction.Draw();
                if (instruction.IsClicked(SplashKit.MousePosition()))
                {
                    if (monster != null)
                    {
                        savingManager.Save_with_monster(spaceship, monster, items, "/Users/khanhvu/Desktop/Spacefighters.txt", false);
                        endgame = true;
                        InstructionPage();
                    }
                    else
                    {
                        savingManager.Save_with_Chicken(spaceship, chickens, items, "/Users/khanhvu/Desktop/Spacefighters.txt", false);
                        endgame = true;
                        InstructionPage();
                    }
                }
                if (SplashKit.KeyTyped(KeyCode.EscapeKey))
                {
                    endgame = true;
                    PreviousPage();
                }

                if (create_monster)
                {
                    have_chicken = false;
                    if (monster == null)
                    {
                        monster = initialize.CreateMonsters(monster, spaceship, choice);

                        choice = choice + 1;
                    }
                    else
                    {
                        if (monster.Dead == true)
                        {
                            monster = initialize.CreateMonsters(monster, spaceship, choice);
                            
                            choice = choice + 1;
                        }
                    }
                }

                if (choice >= 3)
                {

                    foreach (GameObject gameObject in monster.Inventory.List)
                    {
                        if (gameObject is Bullet)
                        {

                            ((Bullet)gameObject).Enemy = monster.Enemy;
                            ((Bullet)gameObject).Chase(2f);
                            ((Bullet)gameObject).Y = ((Bullet)gameObject).Y + ((Bullet)gameObject).Speed;
                            ((Bullet)gameObject).ActivateDeadTime();
                        }
                       
                    }
                }
                if(choice == 5)
                {
                    monster.UltimateEffect();
                }


                items = initialize.CreateItems(items);

                handler.Check();
                if (monster != null)
                {
                    handler.CheckMonsterState(monster);
                }



                create_monster = true;
                if (spaceship.Dead == false)
                {
                    spaceship.Draw();
                }
                else
                {
                    endgame = true;
                    PreviousPage();
                }
                if (monster != null)
                {
                    monster.Draw();
                    monster.DrawHP();
                }

                foreach (Item item in items)
                {
                    item.Draw();
                }
                foreach (Chicken chicken in chickens)
                {
                    if (chicken.Dead == false)
                    {
                        chicken.Draw();
                        create_monster = false;
                    }
                }

                SplashKit.RefreshScreen();

                if (window.CloseRequested)
                {
                    endgame = true;
                }


                if (choice == 5 && monster.Dead == true)
                {
                    endgame = true;
                    NextPage();
                }
            }
            while (endgame == false);

            playMusic = false;
        }
        public void PreviousPage()
        {
            backgroundmusic.DoFree();

            GameManager.GetGameManager(window).CurrentPage = new MainMenu(window);
        }
        public void NextPage()
        {
            backgroundmusic.DoFree();

            GameManager.GetGameManager(window).CurrentPage = new Victory(window);
        }
        public void InstructionPage()
        {
            backgroundmusic.DoFree();
            GameManager.GetGameManager(window).CurrentPage = new InstructionPage(window, true, true,have_chicken);
        }
    }
}

