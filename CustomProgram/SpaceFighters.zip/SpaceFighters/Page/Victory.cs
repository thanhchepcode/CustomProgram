﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Victory:GamePage
    {
        private Bitmap bg_img;
        private Window window;
        private Button play_again;
        private Button main_menu;
        public Victory(Window game_window)
        {
            play_again = new Button(SplashKit.LoadBitmap("Play_again", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Play_again.png"), 400, 400);
            main_menu = new Button(SplashKit.LoadBitmap("Main_menu", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Main_menu.png"), 400, 500);
            window = game_window;
            bg_img = SplashKit.LoadBitmap("Background image", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Victory_page.png");
        }
        public void Update()
        {
            // 2 buttons are in this page. One allows you to play again, the other brings to the main menu
            SplashKit.ProcessEvents();
            window.Clear(Color.White);
            SplashKit.DrawBitmap(bg_img,0,0);
            play_again.Draw();
            main_menu.Draw();
            if (play_again.IsClicked(SplashKit.MousePosition()))
            {
                PreviousPage();
            }
            if (main_menu.IsClicked(SplashKit.MousePosition()))
            {
                NextPage();
            }
            window.Refresh(60);

        }
        public void PreviousPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new MediumGame(window);
        }
        public void NextPage()
        {
            GameManager.GetGameManager(window).CurrentPage = new MainMenu(window);
        }
    }
}

