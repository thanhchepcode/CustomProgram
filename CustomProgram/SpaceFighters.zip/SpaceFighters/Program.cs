using System;
using SplashKitSDK;

namespace SpaceFighters
{
    public class Program
    {
        public static void Main()
        {
            Window window = new Window("Space fighters", 800, 600);
            while (!window.CloseRequested)
            {
                GameManager.GetGameManager(window).Update();
            }
        }
    }
}
