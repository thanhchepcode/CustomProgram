﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class SavingManager
    {
        private StreamWriter writer;
        private StreamReader reader;
        private Spaceship player;
        private Monster monster;
        private List<Item> items;
        private Boolean easy;
        private Window window;
        public SavingManager(Window game_window)
        {
            window = game_window;
        }
        public Spaceship Spaceship
        {
            get
            {
                return player;
            }
            set
            {
                player = value;
            }
        }
        public Monster Monster
        {
            get
            {
                return monster;
            }
            set
            {
                monster = value;
            }
        }
        public List<Item> Items
        {
            get
            {
                return items;
            }
            set
            {
                items = value;
            }
        }

        public void Save_with_Chicken(Spaceship s, List<Chicken> chickens, List<Item> items, string filename, Boolean easy)
        {
            writer = new StreamWriter(filename);
            try
            {
                // The first 3 lines are the horizontal and vertical of the spaceship. 
                writer.WriteLine(s.X);
                writer.WriteLine(s.Y);
                writer.WriteLine(s.HP);

                //Only writes the properties of the alive chickens in the file.
                foreach(Chicken chicken in chickens)
                {
                    if(chicken.Dead == false)
                    {
                        writer.WriteLine("c");
                        writer.WriteLine(chicken.X);
                        writer.WriteLine(chicken.Y);
                    }
                }


                // The letter is used to indicate the type of items in the file.
                foreach (Item item in items)
                {
                    if(item.Dead == false)
                    {
                        if (item is Rock)
                        {
                            writer.WriteLine("r");
                        }
                        else if (item is Bomb)
                        {
                            writer.WriteLine("b");
                        }
                        else if (item is Heart)
                        {
                            writer.WriteLine("h");
                        }
                        writer.WriteLine(item.X);
                        writer.WriteLine(item.Y);
                    }
                    
                }


            }
            finally
            {
                writer.Close();
            }
        }

        public void Save_with_monster(Spaceship s, Monster m, List<Item> items, string filename, Boolean easy)
        {
            writer = new StreamWriter(filename);
            try
            {
                // Write the properties of spaceship and monster.
                writer.WriteLine(s.X);
                writer.WriteLine(s.Y);
                writer.WriteLine(s.HP);
                writer.WriteLine(m.ID);
                writer.WriteLine(m.X);
                writer.WriteLine(m.Y);
                writer.WriteLine(m.HP);

                // The rest are the same as the previous one.
                foreach(Item item in items)
                {
                    if(item.Dead == false)
                    {
                        if (item is Rock)
                        {
                            writer.WriteLine("r");
                        }
                        else if (item is Bomb)
                        {
                            writer.WriteLine("b");
                        }
                        else if (item is Heart)
                        {
                            writer.WriteLine("h");
                        }
                        writer.WriteLine(item.X);
                        writer.WriteLine(item.Y);
                    }
                }
                    


            }
            finally
            {
                writer.Close();
            }

        }

        public GamePage Load(string filename, Boolean easy)
        {
            try
            {
                // First, find the number of lines in the file.
                string[] lines = File.ReadAllLines(filename);
                int numofLines = lines.Length;
                Spaceship spaceship = new Spaceship(0, 0, "Spaceship");
                Monster monster;
                reader = new StreamReader(filename);
                spaceship.X = reader.ReadSingle();
                spaceship.Y = reader.ReadSingle();
                spaceship.HP = reader.ReadInteger();
                int id = reader.ReadInteger();

                switch (id)
                {
                    case 2:
                        monster = new Planet(0, 0, "Planet.");
                        break;
                    case 3:
                        monster = new Star(0, 0, "Star.");
                        break;
                    case 4:
                        monster = new BlackHole(0, 0, "BlackHole.");
                        break;
                    default:
                        monster = new BlackHole(0, 0, "Galaxy.");
                        break;
                }
                // The switch function up there is read the type of the monster.
                monster.X = reader.ReadSingle();
                monster.Y = reader.ReadSingle();
                monster.HP = reader.ReadInteger();
                monster.Enemy = spaceship;

                List<Item> items = new List<Item> { };

                for(int i =0;i<=(numofLines - 7) / 3; i++)
                {
                    string create = reader.ReadLine();
                    float x_pos = reader.ReadSingle();
                    float y_pos = reader.ReadSingle();

                    Item item;
                    if(create == "b")
                    {
                        item = new Bomb(x_pos, y_pos);
                    }
                    else if(create == "r")
                    {
                        item = new Rock(x_pos, y_pos);
                    }
                    else
                    {
                        item = new Heart(x_pos, y_pos);
                    }
                    items.Add(item);
                }

                if (easy)
                {
                    GamePage return_this = new EasyGame(window, spaceship, monster, items);
                    return return_this;
                }
                else
                {
                    GamePage return_this = new MediumGame(window, spaceship, monster, items);
                    return return_this;
                }
            }
            finally
            {
                reader.Close();
            }
            
        }

        public GamePage Load_With_Chicken(string filename, Boolean easy)
        {
            try
            {

                string[] lines = File.ReadAllLines(filename);
                int numofLines = lines.Length;
                Spaceship spaceship = new Spaceship(0, 0, "Spaceship");
                Monster monster;
                reader = new StreamReader(filename);
                spaceship.X = reader.ReadSingle();
                spaceship.Y = reader.ReadSingle();
                spaceship.HP = reader.ReadInteger();

                List<Chicken> chickens = new List<Chicken> { };
                string type = reader.ReadLine();

                // This is the tricky part. You have to tell the reader to keep reading until no "c" is left in the file.
                while(type == "c")
                {
                    float pos_x = reader.ReadSingle();
                    float pos_y = reader.ReadSingle();
                    Chicken chicken = new Chicken(pos_x, pos_y,"chicken");
                    chicken.Enemy = spaceship;
                    chickens.Add(chicken);
                    type = reader.ReadLine();
                }

                List<Item> items = new List<Item> { };

                float first_x_pos = reader.ReadSingle();
                float first_y_pos = reader.ReadSingle();

                Item item1;
                if (type == "b")
                {
                    item1 = new Bomb(first_x_pos, first_y_pos);
                }
                else if (type == "r")
                {
                    item1 = new Rock(first_x_pos, first_y_pos);
                }
                else
                {
                    item1 = new Heart(first_x_pos, first_y_pos);
                }

                items.Add(item1);


                for (int i =0;i<=(numofLines - 6 - chickens.Count * 3) / 3; i++)
                {
                    string create = reader.ReadLine();
                    float x_pos = reader.ReadSingle();
                    float y_pos = reader.ReadSingle();

                    Item item;
                    if (create == "b")
                    {
                        item = new Bomb(x_pos, y_pos);
                    }
                    else if (create == "r")
                    {
                        item = new Rock(x_pos, y_pos);
                    }
                    else
                    {
                        item = new Heart(x_pos, y_pos);
                    }
                    items.Add(item);
                }

                if (easy)
                {
                    GamePage return_this = new EasyGame(window, spaceship, chickens, items);
                    return return_this;
                }
                else
                {
                    GamePage return_this = new MediumGame(window, spaceship, chickens, items);
                    return return_this;
                }

            }
            finally
            {
                reader.Close();
            }
        }
    }
}

