﻿using System;
using SplashKitSDK;
namespace SpaceFighters
{
    public class Spaceship:Entities
    {

        private SpaceshipBullet bullet;
        private SoundEffect shootingSound;
        private Boolean shoot;
        public Spaceship(float x, float y,string des):base(x,y,des)
        {
            shootingSound = new SoundEffect("Shooting sound", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/Shooting_sound.mp3");
            this.HP = 10;
            shoot = false;
            this.Image = SplashKit.LoadBitmap("spaceship", "/Users/khanhvu/Desktop/Swin_courses/2023_sem2/COS20007/SpaceFighters/image/spaceship.1.png");

        }
        public void CheckDead()
        {
            if (this.HP <= 0)
            {
                this.Dead = true;
            }
        }
        public override void Draw()
        {
            CheckDead();
            DrawHP();
            SplashKit.DrawBitmap(this.Image, this.X, this.Y);

            // Draw the bullets on the screen
            foreach (Bullet bullet in this.Bullets)
            {
                bullet.Draw();
            }
            Control();

        }
        
        public void Control()
        {
            // Shoot bullet if the space key is pressed.
            if (SplashKit.KeyTyped(KeyCode.SpaceKey))
            {
                shootingSound.Play();
                bullet = new SpaceshipBullet(1, 5, this.X, this.Y);
                this.Bullets.Add(bullet);
            }

            if (SplashKit.KeyDown(KeyCode.LeftKey))
            {
                if (this.X > 3)
                {
                    this.X = this.X - 3;
                }

            }
            if (SplashKit.KeyDown(KeyCode.RightKey))
            {
                if (this.X < 750)
                {
                    this.X = this.X + 3;
                }

            }
            if (SplashKit.KeyDown(KeyCode.UpKey))
            {
                if (this.Y > 5)
                {
                    this.Y = this.Y - 3;
                }
            }
            if (SplashKit.KeyDown(KeyCode.DownKey))
            {
                if (this.Y < 550)
                {
                    this.Y = this.Y + 3;
                }
            }

        }
        public override void DrawHP()
        {
            for (int i = 0; i < this.HP; i++)
            {
                SplashKit.FillRectangle(Color.Red, 750 - 20 * i, 550, 20, 20);
            }

        }
    }
}

